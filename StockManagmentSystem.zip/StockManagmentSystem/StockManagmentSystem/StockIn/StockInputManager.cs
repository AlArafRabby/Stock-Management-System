﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace StockManagmentSystem.StockIn
{
    
    public class StockInputManager
    {
        StockInputGateway aStockInputGateway = new StockInputGateway();

        public List<Company.Company> GetAllCompany()
        {
            return aStockInputGateway.GetAllCompany();
        }
        public List<Item.Item> GetAllItem(string selectedValue)
        {
            return aStockInputGateway.GetAllItem(selectedValue);
        }


        public int GetReorderLevel(int ItemId)
        {
            return aStockInputGateway.GetReorderLevel(ItemId);
        }

        public string Saved(StockInput aStockInput)
        {
            int rowAffected = aStockInputGateway.Saved(aStockInput);
            if (rowAffected > 0)
                return "Saved";
            else
            {
                return "Failed";
            }
        }

        public int GetSIQuantity(int ItemId)
        {
            return aStockInputGateway.GetSIQuantity(ItemId);
        }
    }
}