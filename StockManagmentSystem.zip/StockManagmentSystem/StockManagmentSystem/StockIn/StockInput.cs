﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace StockManagmentSystem.StockIn
{
    public class StockInput
    {
        public int CompanyId { get; set; }
        public int ItemId { get; set; }
        public int  ReorderLevel { get; set; }
        public int  AvailableQuantity { get; set; }
        public int  SIQuantity { get; set; }
        public DateTime DateTime { get; set; }
    }
}