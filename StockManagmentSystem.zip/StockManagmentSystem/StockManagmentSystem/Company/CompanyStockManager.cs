﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace StockManagmentSystem.Company
{
    public class CompanyStockManager
    {
        CompanyGateway aCompanyGateway = new CompanyGateway();

        public bool IsExist(string CompanyName)
        {
            return aCompanyGateway.IsExist(CompanyName);
        }

        public string Save(Company aCompany)
        {
            if (IsExist(aCompany.CompanyName))
            {
                return "Copany is Already Exist.";
            }

            int rowAffected = aCompanyGateway.Save(aCompany);
            if (rowAffected > 0)
                return "Saved";
            else
            {
                return "Failed";
            }
        }


        public List<Company> GetAllCompany()
        {
            return aCompanyGateway.GetAllCompany();
        } 



    }
}