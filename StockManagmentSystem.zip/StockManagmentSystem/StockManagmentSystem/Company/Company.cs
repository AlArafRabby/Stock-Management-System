﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace StockManagmentSystem.Company
{
    public class Company
    {
        public int SL { get; set; }
        public int CompanyId { get; set; }
        public string CompanyName { get; set; }

    }
}