﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using StockManagmentSystem.Category;
using StockManagmentSystem.Company;

namespace StockManagmentSystem.Item
{
    public partial class ItemSetup : System.Web.UI.Page
    {
        CategoryStockManager aCategoryStockManager = new CategoryStockManager();
        CompanyStockManager aCompanyStockManager = new CompanyStockManager();
        ItemStockManager aItemStockManager = new ItemStockManager();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GetAllCompany();
                GetAllCategory();
            }
            

        }

        protected void ItemSaveButton_Click(object sender, EventArgs e)
        {
            Item aItem = new Item();
            aItem.CategoryId = Convert.ToInt32(ItemCategoryDropDownList.SelectedValue);
            aItem.CompanyId = Convert.ToInt32(ItemCompanyDropDownList.SelectedValue);
            aItem.ItemName = ItemNameTextBox.Text;
            aItem.AvailableQuantity = 0;
            aItem.ItemReorderLevel = Convert.ToInt32(ItemReorderLevelTextBox.Text);

            aItemStockManager.Save(aItem);
            MessageBox.Show("Item are Save.");

        }

        public void GetAllCompany()
        {
            List<Company.Company> aCompany = aCompanyStockManager.GetAllCompany();
            ItemCompanyDropDownList.DataSource = aCompany;
            ItemCompanyDropDownList.DataTextField = "CompanyName";
            ItemCompanyDropDownList.DataValueField = "CompanyId";
            ItemCompanyDropDownList.DataBind();


        }

        public void GetAllCategory()
        {
            List<Category.Category> aCategore = aCategoryStockManager.GetAllCategory();
            ItemCategoryDropDownList.DataSource = aCategore;
            ItemCategoryDropDownList.DataTextField = "CategoryName";
            ItemCategoryDropDownList.DataValueField = "CategoryId";
            ItemCategoryDropDownList.DataBind();

        }

    }
}