﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls.WebParts;

namespace StockManagmentSystem.Item 
{
    public class ItemStockGateway: GetWay
    {
        public int Save(Item aItem)
        {
            Connection.Open();
            Query = "INSERT INTO Item (ItemName, ReorderLevel, CategoryId, CompanyId,AvailableQuantity) VALUES ('" + aItem.ItemName + "', '" + aItem.ItemReorderLevel + "', '" + aItem.CategoryId + "', '" + aItem.CompanyId + "','"+aItem.AvailableQuantity+"');";
            Command = new SqlCommand(Query, Connection);
            int rowCount = Command.ExecuteNonQuery();
            Connection.Close();
            return rowCount;
        }

        public List<Item> GetAllItem()
        {
           Connection.Open();
           Query = "Select* from Item;";
           Command = new SqlCommand(Query, Connection);
           Reader = Command.ExecuteReader();
           List<Item> items = new List<Item>();

           while (Reader.Read())
           {
               Item aitItem = new Item();
               aitItem.ItemId = (int) Reader["ItemId"];
               aitItem.ItemName= (string) Reader["ItemName"];
               
               items.Add(aitItem);
           }
           Reader.Close();
           Connection.Close();
           return items;

        }

        public int GetReorderLevel(int ItemId)
        {
            int ReorderLevel = 0;
            Connection.Open();
            Query = "select * from Item where ItemId = '" + ItemId + "';";
            Command = new SqlCommand(Query,Connection);
            Reader = Command.ExecuteReader();
            while (Reader.Read())
            {
                ReorderLevel = (int) Reader["ReorderLevel"];
            }
            
            Reader.Close();
            Connection.Close();
            return ReorderLevel;
        }


        public List<Item> GetItemSummary(Item aitem)
        {
            Connection.Open();
            Query = "select * from ShowAllItem where CategoryId='"+aitem.CategoryId+"'   and CompanyId='"+aitem.CompanyId+"';";
            Command = new SqlCommand(Query, Connection);
            Reader = Command.ExecuteReader();
            List<Item> items = new List<Item>();
            int SL = 0;
            while (Reader.Read())
            {
                SL = SL + 1;
                Item aitItem = new Item();
                
                aitItem.ItemName = (string)Reader["ItemName"];
                aitItem.AvailableQuantity = (int) Reader["AvailableQuantity"];
                aitItem.ItemReorderLevel = (int) Reader["ReorderLevel"];
                aitItem.CategoryName = (string) Reader["CategoryName"];
                aitItem.CompanyName = (string) Reader["CompanyName"];
                aitItem.SL = SL;
                items.Add(aitItem);
            }
            Reader.Close();
            Connection.Close();
            return items;

        }
    }
}