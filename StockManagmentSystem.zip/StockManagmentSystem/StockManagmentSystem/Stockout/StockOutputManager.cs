﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Web;

namespace StockManagmentSystem.Stockout
{
    public class StockOutputManager
    {
        StockOutputGateway aStockOutputGateway = new StockOutputGateway();

        public List<Company.Company> GetAllCompany()
        {
            return aStockOutputGateway.GetAllCompany();
        }
        public List<Item.Item> GetAllItem(string selectedValue)
        {
            return aStockOutputGateway.GetAllItem(selectedValue);
        }


        public int GetReorderLevel(int ItemId)
        {
            return aStockOutputGateway.GetReorderLevel(ItemId);
        }
        public int GetAvailableQuantity(int ItemId)
        {
            return aStockOutputGateway.GetAvailableQuantity(ItemId);
        }

        public int DeletStockOutputs()
        {
            return aStockOutputGateway.DeletStockOutputs();
        }

        public int AddStockOutputs(StockOutput aStockOutput)
        {
            return aStockOutputGateway.AddStockOutputs(aStockOutput);
        }

        public List<StockOutput> GetAllStockOut()
        {
            return aStockOutputGateway.GetAllStockOut();
        }

        public int SellStockOutputlist(List<StockOutput> selList)
        {
            return aStockOutputGateway.SellStockOutputlist(selList);
        }

        public int DamageStockOutputlist(List<StockOutput> selList)
        {
            return aStockOutputGateway.DamageStockOutputlist(selList);
        }

        public int LostStockOutputlist(List<StockOutput> selList)
        {
            return aStockOutputGateway.LostStockOutputlist(selList);
        }

        public List<StockOutput> GetAllSaleItem(string from,string to)
        {
            return aStockOutputGateway.GetAllSaleItem(from,to);
        }
    }
}