﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace StockManagmentSystem.Category
{
    public class CategoryStockGateway : GetWay
    {
        public int Save(Category aCategory)
        {
           Connection.Open();
           Query = "INSERT INTO Category(CategoryName) Values('" + aCategory.CategoryName + "')";
           Command = new SqlCommand(Query, Connection);
           int rowCount = Command.ExecuteNonQuery();
           Connection.Close();
           return rowCount;
        }

        public bool IsExist(string CategoryName)
        {
            Connection.Open();
            Query = "SELECT * FROM Category  WHERE CategoryName ='" + CategoryName + "'";
            Command = new SqlCommand(Query, Connection);
            Reader = Command.ExecuteReader();
            bool hasRow = Reader.HasRows;
            Reader.Close();
            Connection.Close();
            return hasRow;
        }


        public List<Category> GetAllCategory()
        {
            Connection.Open();
            Query = "SELECT * FROM Category";
            Command = new SqlCommand(Query, Connection);
            Reader = Command.ExecuteReader();
            List<Category> category = new List<Category>();
            int SL = 0;

            while (Reader.Read())
            {
                SL = SL + 1;
                Category aCategory = new Category();
                aCategory.CategoryName = Reader["CategoryName"].ToString();
                aCategory.CategoryId = (int)Reader["CategoryId"];
                aCategory.SL = SL;
                category.Add(aCategory);


            }
            Reader.Close();
            Connection.Close();
            return category;
        }

        public int UpdateItem(string CategoryName, string CatId)
        {
            Connection.Open();
            Query = "UPDATE Category SET CategoryName = '"+CategoryName+"' WHERE CategoryId='"+CatId+"' ;";
            Command = new SqlCommand(Query, Connection);
            int rowCount = Command.ExecuteNonQuery();
            Connection.Close();
            return rowCount;
        }
    }
}