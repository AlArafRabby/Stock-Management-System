﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using Label = System.Web.UI.WebControls.Label;
using TextBox = System.Web.UI.WebControls.TextBox;


namespace StockManagmentSystem.Category
{
    public partial class CategorySetup : System.Web.UI.Page
    {
        static CategoryStockManager aCategoryStockManager = new CategoryStockManager();
        protected void Page_Load(object sender, EventArgs e)
        {
            List<Category> category = aCategoryStockManager.GetAllCategory();
            CategoryGridView.DataSource = category;
            CategoryGridView.DataBind();
            
        }

        protected void CategorySaveButton_Click(object sender, EventArgs e)
        {
            Category aCategory = new Category();
            aCategory.CategoryName = CategoryNameTextBox.Text;
            aCategoryStockManager.Save(aCategory);
            MessageBox.Show("Category are Save.");

            List<Category> category = aCategoryStockManager.GetAllCategory();
           CategoryGridView.DataSource = category;
            CategoryGridView.DataBind();
        }

        protected void CategoryGridView_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            e.Cancel = true;
            CategoryGridView.EditIndex = -1;

            List<Category> category = aCategoryStockManager.GetAllCategory();
            CategoryGridView.DataSource = category;
            CategoryGridView.DataBind();
        }

        protected void CategoryGridView_RowEditing(object sender, GridViewEditEventArgs e)
        {
            CategoryGridView.EditIndex = e.NewEditIndex;

            List<Category> category = aCategoryStockManager.GetAllCategory();
            CategoryGridView.DataSource = category;
            CategoryGridView.DataBind();
        }

        protected void CategoryGridView_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow r = CategoryGridView.Rows[e.RowIndex];

            TextBox t = (TextBox) r.FindControl("txtName");
            Label l = (r.FindControl("CatId") as Label);
            aCategoryStockManager.UpdateItem(t.Text,l.Text);
            CategoryGridView.EditIndex = -1;

            List<Category> category = aCategoryStockManager.GetAllCategory();
            CategoryGridView.DataSource = category;
            CategoryGridView.DataBind();
        }
    }
}