﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace StockManagmentSystem.Category
{
    public class CategoryToUpdate
    {

        public int ID { get; set; }
        public string FieldValue { get; set; }
        public string ColumnToUpdate { get; set; }
    }
}