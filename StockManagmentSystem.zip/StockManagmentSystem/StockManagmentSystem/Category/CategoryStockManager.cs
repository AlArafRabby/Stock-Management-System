﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace StockManagmentSystem.Category
{
    public class CategoryStockManager
    {
        CategoryStockGateway aStockGetWay = new CategoryStockGateway();

        public bool IsExist(string categoryName)
        {
            return aStockGetWay.IsExist(categoryName);
        }

        public string Save(Category aCategory)
        {
            if (IsExist(aCategory.CategoryName))
            {
                return "Category is Already Exist.";
            }

            int rowAffected = aStockGetWay.Save(aCategory);
            if (rowAffected > 0)
                return "Saved";
            else
            {
                return "Failed";
            }
        }


        public List<Category> GetAllCategory()
        {
            return aStockGetWay.GetAllCategory();
        }

        public int UpdateItem(String CategoryName, String CatId)
        {
            return aStockGetWay.UpdateItem(CategoryName,CatId);
        }

    }
}